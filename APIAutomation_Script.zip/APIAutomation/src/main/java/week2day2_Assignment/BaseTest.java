package week2day2_Assignment;

public class BaseTest {
	
	String ID="";

}
