package week3day2;

public class BaseTest {
	
	public static String sys_id;

}
