package channing;

public class BaseAPI {

	public static String sysID = ""; 
	
}
